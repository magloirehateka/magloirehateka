package com.microservices.offers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OffersApplicationTests {

	@Test
	void contextLoads() {
	}

}
