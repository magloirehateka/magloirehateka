# microservices-architect-config-starter

offers-microservice-spring-boot

Microservice which returns List of Offers
Spring boot 

API 
